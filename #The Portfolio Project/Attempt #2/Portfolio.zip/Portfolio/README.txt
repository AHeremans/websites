Github: https://github.com/AHeremans/websites/tree/main/%23The%20Portfolio%20Project/Attempt%20%232/Portfolio

Combell: https://thomasmoreah.be/project1/index.html